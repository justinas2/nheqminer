#!/bin/sh
# gpu
while true; do ./nheqminer-gpu -l pool.serverpower.net:3857 -u WALLET_ADDRESS.WORKER_NAME -cd 0; echo "sleep & restart"; sleep 30; done