Release
=======
nheqminer-gpu (CPU & GPU >= SM 5.0, AVX and CUDA)[USE_CPU_XENONCAT, USE_CUDA_DJEZO]

NOTE: nheqminer-gpu depends on CUDA capable graphics card with "Compute Capability" >= 5.0 and CUDA driver for MAC (/usr/local/cuda/lib/libcuda.dylib)

Usage
=====
Simple benchmarks:
$ ./nheqminer-cpu -b -t 2
$ ./nheqminer-gpu -b -cd 0

Mining examples:
$ ./nheqminer-gpu -l pool.serverpower.net:3857 -u BTGADRESS.yourworker -cd 0

or change vars in miner.sh and start it with
$ ./miner.sh